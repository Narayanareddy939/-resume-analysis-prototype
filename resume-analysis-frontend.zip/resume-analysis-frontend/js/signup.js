document.getElementById('signupForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const email = e.target.email.value;
  const password = e.target.password.value;

  fetch('http://localhost:3000/signup', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ email, password })
  }).then(res => res.json())
    .then(data => {
      localStorage.setItem('token', data.token);
      window.location.href = 'upload.html';
    }).catch(err => {
      alert('Signup failed!');
    });
});
