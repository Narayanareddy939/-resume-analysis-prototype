document.getElementById('uploadForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const resume = e.target.resume.files[0];
  const jobDescription = e.target.jobDescription.value;

  const formData = new FormData();
  formData.append('resume', resume);
  formData.append('jobDescription', jobDescription);

  fetch('http://localhost:5000/analyze', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('token')}`
    },
    body: formData
  }).then(res => res.json())
    .then(data => {
      localStorage.setItem('results', JSON.stringify(data));
      window.location.href = 'results.html';
    }).catch(err => {
      alert('Upload failed!');
    });
});
