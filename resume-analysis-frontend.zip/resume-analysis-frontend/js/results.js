window.onload = function () {
  const data = JSON.parse(localStorage.getItem('results'));
  if (!data) return;

  document.getElementById('score').textContent = data.score;
  const missingSkillsList = document.getElementById('missingSkills');
  data.missingSkills.forEach(skill => {
    const li = document.createElement('li');
    li.textContent = skill;
    missingSkillsList.appendChild(li);
  });
  const resourcesList = document.getElementById('resources');
  data.learningResources.forEach(resource => {
    const li = document.createElement('li');
    li.textContent = resource;
    resourcesList.appendChild(li);
  });
};
